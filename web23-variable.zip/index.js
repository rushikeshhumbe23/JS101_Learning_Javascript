let a = 10;

let b = 120;

if(a==b){
  console.log("Equal");
}
  