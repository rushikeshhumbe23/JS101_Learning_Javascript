let bug= 100 ;

if(bug >= 5000){
  console.log("Dominos");
}else if(bug >= 2000){
  console.log("Dhaba");
}else if(bug >=100){
  console.log("tea party ");
}else if(bug >= 500){
  console.log("vada pav");
}else if(bug >= 10){
  console.log("Eclares");
}else{
  console.log("Ghar pe raho");
}