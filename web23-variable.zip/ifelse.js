let pur = 3000;
 let min_pur = 3999;

if(pur >= min_pur){
  console.log("He is eligible for discount");
}
else{
  console.log("not eligible");
  
}

