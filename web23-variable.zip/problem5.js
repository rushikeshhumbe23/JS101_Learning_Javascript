let bill = 4000;
 let min =3999;

if(bill>= min){
  console.log("The new bill is",bill*0.9);
  
}
else{
  console.log("Not Eiligible");
}
  