var x = 12;
x = 13;
x = 56;
x = 1;
X = 15;

let y = 18;
y = 20;
y = 30;

const z = 29;
//z = 3;


console.log(z);
console.log(x);
console.log(y);