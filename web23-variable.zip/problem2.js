const x=23;

console.log(x);